<?php
session_start();
require_once 'conexion.php'; // contiene $conn con mysqli_connect

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $telefono = trim($_POST['telefono']);
    $empresa = trim($_POST['empresa']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "Email no válido";
    }

    if (strlen($password) < 6) {
        $errores[] = "La contraseña debe tener al menos 6 caracteres";
    }

    $stmt = $conn->prepare("SELECT id FROM clientes WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errores[] = "El email ya está registrado";
    }
    $stmt->close();

    if (empty($errores)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO clientes (nombre, email, password_hash, telefono, empresa) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nombre, $email, $hash, $telefono, $empresa);

        if ($stmt->execute()) {
            header("Location: login.php");
            exit();
        } else {
            $errores[] = "Error al registrar: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<?php include 'header.php'; ?>
<div class="formulario">
  <h2>Registro de Cliente</h2>
  <?php if (!empty($errores)): ?>
    <div class="errores">
      <ul>
        <?php foreach ($errores as $error): ?>
          <li><?php echo htmlspecialchars($error); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post">
    <input type="text" name="nombre" placeholder="Nombre completo" required>
    <input type="email" name="email" placeholder="Correo electrónico" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <input type="text" name="telefono" placeholder="Teléfono">
    <input type="text" name="empresa" placeholder="Empresa">
    <button type="submit">Registrarse</button>
  </form>
  <p>¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
</div>
<?php include 'footer.php'; ?>
